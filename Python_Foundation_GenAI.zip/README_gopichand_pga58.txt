# Customer Feedback Analysis and Automated Response

## Imarticus Data Science Internship Assessment
### Python Foundations and Generative AI

## Project Overview

This project analyzes customer feedback for a retail business. It identifies low-rated reviews, finds common 
complaint keywords, and uses Gemini to draft personalized apology emails for three critical reviews.

## Dataset

The dataset represents retail product reviews. It contains 50,000 review-style records with fields such as 
review ID, star rating, review title, review text, product category, and purchase verification status.

The current practice dataset contains **synthetically generated review records**. It demonstrates the analysis
workflow but is not real customer feedback.

## Development Environment

The project was prepared in Visual Studio Code using its integrated terminal. Python version 3.14.6 was used. 
A project virtual environment was created and activated, and the required packages were installed in it.

## Packages Used

Pandas was used to load, clean, and analyze the review dataset. The `google-genai` package was used to 
connect to Gemini and generate apology email drafts. The `python-dotenv` package was used to load the 
Gemini API key from a `.env` file. Jupyter was used to run the assessment notebook.

## Gemini API Key Setup

A Gemini API key was created through Google AI Studio and stored in a `.env` file in the project folder. 
The notebook loads the key from that file instead of placing it directly in the notebook code.

Keep the `.env` file private. Do not include it in the submitted project or share it with others. 
If a key has appeared in a notebook, PDF, or screenshot, revoke it and create a replacement key.

## Analysis Workflow

1. Load the review data into a Pandas DataFrame.
2. Check required columns and clean missing or invalid ratings.
3. Preserve the original review text and create a cleaned version for analysis.
4. Identify critical reviews using the rule-based condition of 1- or 2-star ratings. No machine learning is used.
5. Count common complaint keywords using basic string matching and Python’s `Counter`.
6. Select three detailed critical reviews.
7. Send each selected review to Gemini to draft a short, personalized, empathetic apology email.
8. Save the notebook with the analysis results and generated emails.

## How to Run

1. Open the project folder in Visual Studio Code.
2. Open the integrated terminal and activate the project virtual environment.
3. Confirm that the `.env` file contains a valid `GEMINI_API_KEY`.
4. Start Jupyter and open the assessment notebook.
5. Run the notebook cells from top to bottom.
6. Confirm that the keyword results and all three generated emails appear.
7. Save the notebook with its outputs before submission.

If Gemini returns a temporary `503 UNAVAILABLE` error, wait and rerun the email-generation cell.

## Output Files

- `cleaned_reviews.csv` — reviews after cleaning.
- `critical_reviews.csv` — reviews rated 1 or 2 stars.
- `complaint_keyword_counts.csv` — complaint keyword frequencies.
- Assessment notebook (`.ipynb`) — code, analysis, and generated email drafts.

## Notes

- Reviews with missing or invalid ratings are removed.
- Missing review text is handled during cleaning.
- Critical reviews are selected by rating, without machine learning.
- One review may contain multiple complaint keywords, so keyword counts can overlap.
- Gemini-generated email drafts should be reviewed before use.